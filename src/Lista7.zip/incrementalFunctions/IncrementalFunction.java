package incrementalFunctions;

public interface IncrementalFunction {
	int shift(int trial);
}
