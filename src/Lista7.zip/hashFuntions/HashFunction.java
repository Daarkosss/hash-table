package hashFuntions;

public interface HashFunction<T> {
	int hashCode(T object);
}
